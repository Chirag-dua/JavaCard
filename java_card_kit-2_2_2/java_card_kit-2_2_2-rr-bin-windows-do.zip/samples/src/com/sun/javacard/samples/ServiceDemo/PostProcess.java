/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/*
 * PostProcess.java
 *
 * Created on October 8, 2001, 2:11 PM
 */

package com.sun.javacard.samples.ServiceDemo;

/**
 *
 * @author  vo113324
 */
public class PostProcess {

    /** Creates new PostProcess */
    public PostProcess() {
    }

}
